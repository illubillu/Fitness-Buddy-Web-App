# 440-Group-14-Fall-2023
Repository for CS 440 Group 14 for Fall 2023

Note:  The presentation evaluation form and rubric are provided here for reference
       and planning purposes.  Hard copies will be handed out in class on 
       presentation days.  ( Unless presentations are given online, in which case
       a Google form will be made available. )
       
       Similarly the Group Project Member Evaluation Rubric is provided here for 
       reference only.  A form will be provided periodically during the term 
       for completion by all group members.
