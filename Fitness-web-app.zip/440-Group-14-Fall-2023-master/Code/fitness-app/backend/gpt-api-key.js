const gpt_key = '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'

export default gpt_key