import mongoose from 'mongoose';
import express from 'express'
import cors from "cors"
import uri from './uri.js'
import Macro from './models/Macros.js'

import gpt_response from './gpt_response.js'

const app = express()

const PORT = process.env.PORT || 5000; 
app.listen(PORT, () => console.log(`Server is running on port ${PORT}`));

app.use(express.json());

// cors
app.use(cors());

mongoose.connect(uri, { useNewUrlParser: true, useUnifiedTopology: true }); //connect to mongoDB


app.post('/addMacro', async (req, res) => { //route to add a macro
    const newMacro = new Macro(req.body);
    try {
      const savedMacro = await newMacro.save();
      res.json(savedMacro);
    } catch (err) {
      res.status(500).json(err);
    }
  });

  app.get('/getMacros', async (req, res) => {//route to retrieve all Macros
    try {
      const macros = await Macro.find();
      res.json(macros);
    } catch (err) {
      res.status(500).json(err);
    }
  });

  app.post('/generate-exercise-routine', async (req, res) => {//route to query gpt api for exercise routine
    try {
      const message = req.body.message;
      const response = await gpt_response(message);
      res.json(response);
    } catch (err) {
      res.status(500).send(err.message);
    }
  });
  

  mongoose.connection.on('open', () => {
    console.log('MongoDB connected successfully.');
});
