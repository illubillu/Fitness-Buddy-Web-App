import mongoose from 'mongoose'
import Macro from './models/Macros.js'
import uri from './uri.js'


mongoose.connect(uri, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  });
  
  mongoose.connection.on('connected', () => {
    console.log('Connected to MongoDB');

    const testMacro = new Macro({
        userId: "651f6e95243b39d86f93199e", // generate a new ObjectId
        proteins: 1,
        carbs: 1,
        fats: 1,
        calories: 1,
        date: "2023-11-30T05:47:04.416Z"
    });
    
      // Saving the test document to the database
      testMacro.save()
        .then(doc => {
          console.log('Document saved!', doc);
          
          // Fetching the test document from the database
          return Macro.findById(doc._id);
        })
        .then(fetchedDoc => {
          console.log('Document fetched!', fetchedDoc);
        })
        .catch(err => {
          console.error('Error:', err);
        });
  });
  
  mongoose.connection.on('error', (err) => {
    console.error('Failed to connect to MongoDB', err);
  });