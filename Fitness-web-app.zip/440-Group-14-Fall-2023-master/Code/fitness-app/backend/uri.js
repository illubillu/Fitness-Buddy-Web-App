const uri = "mongodb://127.0.0.1:27017/fitnesstrackerdb"; 


export default uri
