import mongoose from 'mongoose';

const macroSchema = new mongoose.Schema({
    userId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    date: {
        type: Date,
        default: Date.now
    },
    proteins: {
        type: Number,
        required: true
    },
    carbs: {
        type: Number,
        required: true
    },
    fats: {
        type: Number,
        required: true
    },
    calories: {
        type: Number,
        required: true
    }
});

const Macro = mongoose.model('Macro', macroSchema);

export default Macro
