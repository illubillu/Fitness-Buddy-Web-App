import gpt_key from './gpt-api-key.js';

import OpenAI from 'openai';

const openai = new OpenAI({
    apiKey: gpt_key
});



async function gpt_response(message) { //returns the top response for a new message given the context message history
  const completion = await openai.chat.completions.create({
    messages: [{ role: "system", content: "You are a helpful assistant." }, {role : "user", content : "For the following query, provide strictly the routine: sets, reps, exercise names, etc. Do not elaborate further or explain how to do the exercise. Do this in 100 words or less. Here is the query: " + message}],
    model: "gpt-3.5-turbo",
  });

  return completion.choices[0];
} 

console.log(await gpt_response("How are you today"))
 
export default gpt_response