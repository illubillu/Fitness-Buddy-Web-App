// import logo from './logo.svg';
import './App.css';
import Navbar from './components/navbar/navbar';
import Profile from './components/pfpbar';
import { BrowserRouter as Router, Routes, Route} from 'react-router-dom'
import Nutrition from './pages/nutrition';
import Exercise from './pages/exercise';
import Restaurant from './pages/restaurant';
import Home from './pages';
import React, { useState}  from 'react';
import axios from 'axios';

function App() {
  // State that will be lifted up
  const [routineContent, setRoutineContent] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // Function to update the state
  const fetchRoutineContent = async (userInput) => {
    setIsLoading(true);
    setError('');

    try {
      const response = await axios.post('http://localhost:5000/generate-exercise-routine', {
        message: userInput
      });
      setRoutineContent(response.data.message.content);
    } catch (error) {
      setError('Failed to fetch the exercise routine.');
    } finally {
      setIsLoading(false);
    }
  };
  
  return (
    <div className="App">
      <Router>
        <Profile />
        <Navbar />
        <Routes>
          <Route path='/' element={
            <Home
            routineContent={routineContent}
            isLoading={isLoading}
            error={error}
            fetchRoutineContent={fetchRoutineContent}
          />
          } />
          <Route path='/Nutrition' element={<Nutrition />} />
          <Route path='/Restaurant' element={<Restaurant />} />
          <Route path='/Exercise' element={
            <Exercise
              routineContent={routineContent}
              isLoading={isLoading}
              error={error}
              fetchRoutineContent={fetchRoutineContent}
            />}
          />
        </Routes>
      </Router>
    </div>
  );
}

export default App;
