import React, { useState } from 'react';
import axios from 'axios';
import './exercise.css';

const Exercise = ({ routineContent, isLoading, error, fetchRoutineContent }) => {
    const [userInput, setUserInput] = useState('');

    const handleButtonClick = () => {
      fetchRoutineContent(userInput);
    };
  

  return (
    <div className='exercise-main'>
      <h1 className='exer-title'>Exercise Searcher</h1>
      <input
        type="text"
        placeholder="Enter your exercise goals"
        value={userInput}
        onChange={(e) => setUserInput(e.target.value)}
      />
      <button className="exercise-btn" onClick={handleButtonClick} disabled={isLoading || !userInput}>
        Get Exercise Routine
      </button>
      {isLoading && <p>Loading...</p>}
      {error && <p className="error">{error}</p>}
      {routineContent && (
        <div>
          <h2>Exercise Routine</h2>
          <p className='exercise-result'>{routineContent}</p>
        </div>
      )}
    </div>
  );
};

export default Exercise;
