import React, { useEffect, useState } from "react";
import Axios from 'axios';
import './index.css';

const Home = ({ routineContent, isLoading, error, fetchRoutineContent }) => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showExerciseRoutine, setShowExerciseRoutine] = useState(false);

  const getMacros = async () => {
    const response = await Axios.get("http://localhost:5000/getMacros");
    setData(response.data);
    setLoading(false);
  };

  useEffect(() => {
    getMacros();
  }, []);

  const toggleMacro = () => {
    var form = document.getElementById("macroCalculation");
    if (form.style.display !== 'none') {
      form.style.display = 'none';
    } else {
      form.style.display = 'block';
    }
  };

  const handleFormSubmit = async (e) => {
    e.preventDefault();
    const form = e.target;
    const date = form.querySelector('#date').value;
    const calories = form.querySelector('#calories').value;
    const proteins = form.querySelector('#proteins').value;
    const carbs = form.querySelector('#carbs').value;
    const fats = form.querySelector('#fats').value;
    const userId = 'john johnson';

    try {
      const res = await Axios.post("http://localhost:5000/addMacro", {
        userId,
        date,
        calories,
        proteins,
        carbs,
        fats
      });
      getMacros();
    } catch (err) {
      console.error("Error submitting form:", err);
    }
  };

  //onClick of exercise button
  const handleTodaysExerciseClick = () => {
    if (!routineContent && !showExerciseRoutine) {
      alert("No exercise routine generated yet. Please go to the Exercise page.");
      return;
    }
    setShowExerciseRoutine(!showExerciseRoutine);
  };

  return (
    <div className="index-header">
      <h3 className="title">Welcome to <br /> <span id='title-app'>Fitness and Nutrition Buddy!</span></h3>
      <div className="home-buttons">
        <div style={{ display: 'flex' }}>
          <button type="button" className="homeButton" onClick={handleTodaysExerciseClick}>
            {showExerciseRoutine ? "TODAY'S STATS" : "TODAY'S EXERCISE"}
          </button>
          <button type="button" className="homeButton">TODAY'S MEAL PLAN</button>
        </div>
        {!loading && !showExerciseRoutine && (
          <div className='today-stats'>
            <h2>Today's Stats: {new Intl.DateTimeFormat('en-US', { weekday: 'long' }).format(new Date(data[data.length - 1].date))}</h2>
            <p>
              <span>Calories</span>: {data[data.length - 1].calories}<br />
              <span>Protein</span>: {data[data.length - 1].proteins}<br />
              <span>Carbohydrates</span>: {data[data.length - 1].carbs}<br />
              <span>Fats</span>: {data[data.length - 1].fats}<br />
            </p>
          </div>
        )}
        {showExerciseRoutine && (
          <div className='today-stats'>
            <h2>Today's Exercise Routine</h2>
            <p>{routineContent}</p>
          </div>
        )}
        <br></br>
        <button type="button" className="homeButton" onClick={() => toggleMacro()}>MACRO CALCULATION</button>
      </div>

      <form onSubmit={handleFormSubmit} action="/submit-form" method="post" id="macroCalculation" style={{ display: "none" }}>
        <div className='form-group'>
          <label htmlFor="date">Date:</label>
          <input type="date" name="date" id="date" required></input>
        </div>
        <br></br>
        <div>
          <label htmlFor="calories">Calories:</label>
          <input type="number" name="calories" id="calories" required></input>
        </div>
        <br></br>
        <div>
          <label htmlFor="proteins">Proteins:</label>
          <input type="number" name="proteins" id="proteins" required></input>
        </div>
        <br></br>
        <div>
          <label htmlFor="carbs">Carbs:</label>
          <input type="number" name="carbs" id="carbs" required></input>
        </div>
        <br></br>
        <div>
          <label htmlFor="fats">Fats:</label>
          <input type="number" name="fats" id="fats" required></input>
        </div>
        <br></br>
        <button type="submit">Submit</button>
      </form>

    </div>
  );
};

export default Home;
