// import React, { useEffect, useState } from "react";
// import Axios from 'axios';

import React, { useEffect } from "react";
import './restaurant.css';

const Restaurant = () => {

    const loadGoogleMapScript = () => {
        const googleMapScript = document.createElement('script');
        googleMapScript.src = `https://maps.googleapis.com/maps/api/js?key=AIzaSyA9jnUd4hbQM4USHcxBKrs6YQpKKB4YgWI&libraries=places`;
        googleMapScript.async = true;
        googleMapScript.defer = true;
    
        googleMapScript.addEventListener('load', initializeMap);
        document.body.appendChild(googleMapScript);
    };
    
    const initializeMap = () => {
        const map = new window.google.maps.Map(document.getElementById('map'), {
            center: { lat: 41.86673, lng: -87.6470 },
            zoom: 13,
        });
    
        const input = document.getElementById('restaurant-search');
        const searchBox = new window.google.maps.places.SearchBox(input);
        map.controls[window.google.maps.ControlPosition.TOP_LEFT].push(input);
    
        searchBox.addListener('places_changed', () => {
          const places = searchBox.getPlaces();
    
          if (places.length === 0) {
            return;
          }
    
          const bounds = new window.google.maps.LatLngBounds();
          places.forEach(place => {
            if (!place.geometry) return;
            new window.google.maps.Marker({
              map,
              title: place.name,
              position: place.geometry.location,
            });
            bounds.extend(place.geometry.location);
          });
          map.fitBounds(bounds);
        });
    };
    
    useEffect(() => {
        if (window.google && window.google.maps) {
          initializeMap();
        } else {
          loadGoogleMapScript();
        }
    }, []);
    
    return (
        <div className="restaurant">
            <h1 className="rest-title"> Restaurant Finder </h1>
            <div className="search-container">
                <input id="restaurant-search" type="text" placeholder="Search for restaurants" />
            </div>
            <div id="map" style={{ height: '500px' }}></div>
        </div>
    );

};

export default Restaurant;