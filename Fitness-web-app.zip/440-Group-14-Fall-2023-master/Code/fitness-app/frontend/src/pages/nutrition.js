import React, { useEffect, useState } from "react";
import { PieChart, Pie, Cell, Legend} from 'recharts';
import './nutrition.css';
import Axios from 'axios';

const Nutrition = () => {
    const piedata = [
        { name: 'CaloriesBurned', calories: 10220 },
        { name: 'CaloriesGained', calories: 14910 }
    ];

    const [data,setData] = useState([]);

    const getMacros=async()=> {
        const response = await Axios.get("http://localhost:5000/getMacros");
        setData(response.data);
        console.log(response.data);
    }

    useEffect(() => {
        getMacros()
    },[]);

    const slicedData = data.slice(0, 7);

    const COLORS = ['#00E604', '#E80004'];

    const [popVis, setPopVis] = useState(false);
    const [popTitle, setPopTitle] = useState("");
    const [selectedDayData, setSelectedDayData] = useState(null);

    const togglePop = (dayData) => {
        setPopVis(!popVis);
        setPopTitle(dayData.date);
        setSelectedDayData(dayData);
    };

    return (
        <div className="nutrition">
            {/* {data.map(d => <div>{d.date}</div>)} */}
            <h1 className="nutrition-title"> Weekly Nutrition </h1>
            <table>
                <thead>
                    <th>Sun</th>
                    <th>Mon</th>
                    <th>Tue</th>
                    <th>Wed</th>
                    <th>Thu</th>
                    <th>Fri</th>
                    <th>Sat</th>
                </thead>
                <tbody>
                    {/* <td onClick={() => togglePop("Sunday")}>G: 2130<br/>B: 1460</td>
                    <td onClick={() => togglePop("Monday")}>G: 2130<br/>B: 1460</td>
                    <td onClick={() => togglePop("Tuesday")}>G: 2130<br/>B: 1460</td>
                    <td onClick={() => togglePop("Wednesday")}>G: 2130<br/>B: 1460</td>
                    <td onClick={() => togglePop("Thursday")}>G: 2130<br/>B: 1460</td>
                    <td onClick={() => togglePop("Friday")}>G: 2130<br/>B: 1460</td>
                    <td onClick={() => togglePop("Saturday")}>G: 2130<br/>B: 1460</td> */}
                    {slicedData.map((dayData, i) => (
                        <td key={i} onClick={() => togglePop(dayData)}>
                            G: {dayData.calories}<br />
                        </td>
                    ))}
                </tbody>
            </table>

            {popVis && (
                <div class='popup'>
                    <div class='popup-content'>
                        <h2> {new Intl.DateTimeFormat('en-US', { weekday: 'long' }).format(new Date(popTitle))} </h2>
                        <p>
                            <span>Calories</span>: {selectedDayData.calories}<br/>
                            <span>Protein</span>: {selectedDayData.proteins}<br/>
                            <span>Carbohydrates</span>: {selectedDayData.carbs}<br/>
                            <span>Fats</span>: {selectedDayData.fats}<br/>
                        </p>
                        <button onClick={() => togglePop("")}> Close</button>
                    </div>
                </div>
            )}

            <div class='graph-wrapper'>
                <PieChart width={300} height={300} align="center">
                    <Pie data={piedata} dataKey="calories" outerRadius={100} fill="blue" label>
                        {piedata.map((entry, i) => (
                            <Cell key={`cell-${i}`} fill={COLORS[i % COLORS.length]} />
                        ))}
                    </Pie>
                    <Legend />
                </PieChart>
            </div>
        </div>
    );
};

export default Nutrition;