const axios = require('axios');

async function getExerciseRoutine(inputMessage) {
  try {
    const response = await axios.post('http://localhost:5000/generate-exercise-routine', {
      message: inputMessage
    });

    return response.data;
  } catch (error) {
    console.error('Error while fetching:', error);
    throw error;
  }
}

getExerciseRoutine("I need a workout plan for abs and arms")
  .then(data => {
    console.log(data);
  })
  .catch(err => {
    console.error('Error in getting response:', err);
  });
