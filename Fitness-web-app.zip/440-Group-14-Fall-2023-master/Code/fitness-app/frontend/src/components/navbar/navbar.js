import React from 'react';
import {
  Nav,
  NavLink,
  Bars,
  NavMenu,
  // NavBtn,
  // NavBtnLink,
} from './NavbarElem';
  
const Navbar = () => {
  return (
    <>
      <Nav>
        <Bars />
        <NavMenu>
          <NavLink to='/' activeStyle>
            <img src='/home.png' alt='Home' height={40} width={40}/>
          </NavLink>
          <NavLink to='/Nutrition' activeStyle>
          <img src='/nutrition.png' alt='Nutrition' height={40} width={40}/>
          </NavLink>
          <NavLink to='/Restaurant' activeStyle>
          <img src='/map.png' alt='Restaurant' height={40} width={40}/>
          </NavLink>
          <NavLink to='/Exercise' activeStyle>
          <img src='/exercise.png' alt='Exercise' height={40} width={40}/>
          </NavLink>
        </NavMenu>
        {/* <NavBtn>
          <NavBtnLink to='/signin'>Sign In</NavBtnLink>
        </NavBtn> */}
      </Nav>
    </>
  );
};
  
export default Navbar;