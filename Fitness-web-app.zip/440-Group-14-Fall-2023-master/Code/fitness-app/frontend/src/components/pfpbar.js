import React from 'react';
import './pfpbar.css';
  
const Profile = () => {
    return (
        <div className="profile-container">
            <img src="/defaultpic.jpg" className="defaultpic" alt=""></img>
            <h2 id="username"><span id="pfp-greet">Hello!</span><br/>John Johnson</h2>
        </div>
    );
};
export default Profile;