This directory should hold all files related to the Development project.

Please name files in a meaningful way, bearing in mind that the instructors
are dealing with 30 groups per semester and keep archives going back many years.
Example: "Group N Fall 2020 Description Report", "Group N Fall 2020 Description Summary", etc.
